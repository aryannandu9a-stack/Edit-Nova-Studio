import './style.css';

const app = document.querySelector('#app');
const state = { clips: [], selected: -1, objectUrls: [], exporting: false };

app.innerHTML = `
  <header class="topbar">
    <div class="brand-mark">N</div>
    <div class="brand"><strong>EditNova</strong><span>STUDIO · BETA</span></div>
    <button id="exportBtn" class="primary" disabled>Export video ↗</button>
  </header>
  <main>
    <section class="hero">
      <div><p class="eyebrow">YOUR CREATIVE SPACE</p><h1>Make every frame<br><span>feel cinematic.</span></h1>
      <p class="sub">A mobile-first video editor prototype. Import clips, trim a segment, add a title, and export.</p></div>
      <label class="add-button" for="fileInput">＋ Add videos</label>
      <input id="fileInput" type="file" accept="video/*" multiple hidden />
    </section>
    <section class="workspace">
      <div class="preview-panel panel">
        <div class="panel-head"><span>PREVIEW</span><span id="previewStatus">No clip selected</span></div>
        <div class="preview-wrap" id="previewWrap">
          <div class="empty-state"><div class="play-icon">▶</div><b>Your preview goes here</b><span>Add a video to start editing</span></div>
          <video id="video" playsinline controls hidden></video>
          <canvas id="overlayCanvas" hidden></canvas>
          <div id="titleOverlay" class="title-overlay"></div>
        </div>
        <div class="preview-foot"><span id="videoInfo">9:16 · Shorts-ready workflow</span><span class="live-dot">● LOCAL PREVIEW</span></div>
      </div>
      <div class="settings-panel panel">
        <div class="panel-head"><span>CLIP SETTINGS</span><span class="pill">BETA</span></div>
        <div id="noSelection" class="hint">Choose a clip in your timeline to edit its trim points and title.</div>
        <div id="settings" hidden>
          <label class="field-label">Clip name</label><div id="clipName" class="clip-name"></div>
          <div class="range-head"><label class="field-label">Trim start</label><span id="startLabel">0.0s</span></div>
          <input id="trimStart" type="range" min="0" max="10" step="0.1" value="0" />
          <div class="range-head"><label class="field-label">Trim end</label><span id="endLabel">0.0s</span></div>
          <input id="trimEnd" type="range" min="0" max="10" step="0.1" value="10" />
          <label class="field-label" for="titleInput">Title overlay</label>
          <input id="titleInput" class="text-input" maxlength="70" placeholder="e.g. THE AWAKENING BEGINS" />
          <label class="field-label" for="titlePosition">Title position</label>
          <select id="titlePosition" class="text-input"><option value="bottom">Bottom</option><option value="center">Center</option><option value="top">Top</option></select>
          <p class="tiny-note">Tip: keep titles short and readable on a phone.</p>
          <button id="applyBtn" class="secondary full">Update preview</button>
        </div>
      </div>
    </section>
    <section class="timeline-panel panel">
      <div class="panel-head"><span>PROJECT TIMELINE</span><span id="clipCount">0 clips</span></div>
      <div id="timeline" class="timeline-empty">Your imported clips will appear here.</div>
      <div class="timeline-bottom"><span>Prototype supports trim + title export for the selected clip.</span><button id="clearBtn" class="text-button" disabled>Clear project</button></div>
    </section>
    <section class="notice"><strong>Prototype status</strong><span>This starter exports a selected clip with a text overlay where the browser supports canvas recording. It does not yet provide a full multi-track editor, transitions, or professional codec controls.</span></section>
  </main>
  <footer>EDITNOVA STUDIO <span>Built for creators · 0.1.0</span></footer>
  <div id="toast" role="status" aria-live="polite"></div>
`;

const $ = (id) => document.getElementById(id);
const video = $('video');
const titleOverlay = $('titleOverlay');
const fileInput = $('fileInput');

function showToast(message) {
  const toast = $('toast');
  toast.textContent = message;
  toast.classList.add('show');
  window.clearTimeout(showToast.timer);
  showToast.timer = window.setTimeout(() => toast.classList.remove('show'), 3200);
}
function fmt(sec) {
  if (!Number.isFinite(sec)) return '0:00';
  const m = Math.floor(sec / 60), s = Math.floor(sec % 60);
  return `${m}:${String(s).padStart(2, '0')}`;
}
function selectedClip() { return state.clips[state.selected] || null; }

fileInput.addEventListener('change', async (event) => {
  const files = Array.from(event.target.files || []).filter(f => f.type.startsWith('video/'));
  if (!files.length) return;
  for (const file of files) {
    const url = URL.createObjectURL(file);
    state.objectUrls.push(url);
    const duration = await readDuration(url).catch(() => 0);
    state.clips.push({ file, url, duration, start: 0, end: duration, title: '', position: 'bottom' });
  }
  if (state.selected < 0 && state.clips.length) state.selected = 0;
  fileInput.value = '';
  renderTimeline();
  loadSelected();
});
function readDuration(url) {
  return new Promise((resolve, reject) => {
    const probe = document.createElement('video');
    probe.preload = 'metadata'; probe.src = url;
    probe.onloadedmetadata = () => resolve(Number.isFinite(probe.duration) ? probe.duration : 0);
    probe.onerror = () => reject(new Error('Could not read video metadata'));
  });
}
function renderTimeline() {
  $('clipCount').textContent = `${state.clips.length} clip${state.clips.length === 1 ? '' : 's'}`;
  $('clearBtn').disabled = !state.clips.length;
  $('exportBtn').disabled = !selectedClip() || state.exporting;
  const timeline = $('timeline');
  if (!state.clips.length) {
    timeline.className = 'timeline-empty';
    timeline.textContent = 'Your imported clips will appear here.';
    return;
  }
  timeline.className = 'clip-list';
  timeline.innerHTML = '';
  state.clips.forEach((clip, i) => {
    const item = document.createElement('div');
    item.className = `clip-card ${i === state.selected ? 'selected' : ''}`;
    item.innerHTML = `<div class="clip-thumb"><span>▶</span></div><div class="clip-meta"><strong></strong><span>${fmt(clip.end - clip.start)} · ${fmt(clip.duration)} total</span></div><button class="remove-clip" aria-label="Remove clip">×</button>`;
    item.querySelector('strong').textContent = clip.file.name;
    item.addEventListener('click', (e) => {
      if (e.target.closest('.remove-clip')) return;
      state.selected = i; renderTimeline(); loadSelected();
    });
    item.querySelector('.remove-clip').addEventListener('click', (e) => {
      e.stopPropagation();
      state.clips.splice(i, 1);
      if (!state.clips.length) state.selected = -1;
      else if (state.selected >= state.clips.length) state.selected = state.clips.length - 1;
      else if (i < state.selected) state.selected--;
      renderTimeline(); loadSelected();
    });
    timeline.appendChild(item);
  });
}
function loadSelected() {
  const clip = selectedClip();
  $('noSelection').hidden = !!clip;
  $('settings').hidden = !clip;
  $('exportBtn').disabled = !clip || state.exporting;
  if (!clip) {
    video.pause(); video.hidden = true; titleOverlay.textContent = '';
    $('previewStatus').textContent = 'No clip selected';
    $('videoInfo').textContent = '9:16 · Shorts-ready workflow';
    $('previewWrap').querySelector('.empty-state').hidden = false;
    return;
  }
  $('previewWrap').querySelector('.empty-state').hidden = true;
  video.hidden = false;
  if (video.src !== clip.url) video.src = clip.url;
  video.currentTime = clip.start;
  $('previewStatus').textContent = 'Clip selected';
  $('videoInfo').textContent = `${clip.file.name} · ${fmt(clip.duration)}`;
  $('clipName').textContent = clip.file.name;
  $('trimStart').max = clip.duration;
  $('trimEnd').max = clip.duration;
  $('trimStart').value = clip.start;
  $('trimEnd').value = clip.end;
  $('startLabel').textContent = `${clip.start.toFixed(1)}s`;
  $('endLabel').textContent = `${clip.end.toFixed(1)}s`;
  $('titleInput').value = clip.title;
  $('titlePosition').value = clip.position;
  updateTitle();
}
function updateTitle() {
  const clip = selectedClip();
  if (!clip) return;
  titleOverlay.textContent = clip.title;
  titleOverlay.className = `title-overlay ${clip.position}`;
}
$('trimStart').addEventListener('input', () => {
  const clip = selectedClip(); if (!clip) return;
  clip.start = Math.min(Number($('trimStart').value), clip.end - 0.1);
  $('trimStart').value = clip.start;
  $('startLabel').textContent = `${clip.start.toFixed(1)}s`;
  if (video.currentTime < clip.start || video.currentTime > clip.end) video.currentTime = clip.start;
});
$('trimEnd').addEventListener('input', () => {
  const clip = selectedClip(); if (!clip) return;
  clip.end = Math.max(Number($('trimEnd').value), clip.start + 0.1);
  $('trimEnd').value = clip.end;
  $('endLabel').textContent = `${clip.end.toFixed(1)}s`;
  if (video.currentTime > clip.end) video.currentTime = clip.start;
});
$('titleInput').addEventListener('input', () => { const c = selectedClip(); if(c){ c.title = $('titleInput').value; updateTitle(); } });
$('titlePosition').addEventListener('change', () => { const c = selectedClip(); if(c){ c.position = $('titlePosition').value; updateTitle(); } });
$('applyBtn').addEventListener('click', () => {
  const c = selectedClip(); if (!c) return;
  c.title = $('titleInput').value; c.position = $('titlePosition').value;
  renderTimeline(); updateTitle(); showToast('Preview settings updated.');
});
video.addEventListener('timeupdate', () => {
  const c = selectedClip();
  if (c && video.currentTime >= c.end && !video.paused) { video.pause(); video.currentTime = c.start; }
});

$('clearBtn').addEventListener('click', () => {
  state.clips = []; state.selected = -1;
  renderTimeline(); loadSelected(); showToast('Project cleared.');
});

$('exportBtn').addEventListener('click', async () => {
  const clip = selectedClip();
  if (!clip || state.exporting) return;
  if (!('MediaRecorder' in window) || !HTMLCanvasElement.prototype.captureStream) {
    showToast('Export is not supported in this browser. Try updated Chrome on your laptop.');
    return;
  }
  if (!clip.duration || clip.end <= clip.start) {
    showToast('This video has no valid duration. Try another video.');
    return;
  }
  state.exporting = true;
  $('exportBtn').disabled = true;
  $('exportBtn').textContent = 'Exporting…';
  try {
    await exportClip(clip);
  } catch (err) {
    console.error(err);
    showToast('Export failed on this device. Try a shorter or smaller video.');
  } finally {
    state.exporting = false;
    $('exportBtn').disabled = !selectedClip();
    $('exportBtn').textContent = 'Export video ↗';
  }
});

async function exportClip(clip) {
  const source = document.createElement('video');
  source.src = clip.url; source.muted = false; source.playsInline = true;
  source.preload = 'auto';
  await new Promise((resolve, reject) => {
    source.onloadedmetadata = resolve; source.onerror = () => reject(new Error('Video could not be loaded'));
  });
  const maxW = 720, maxH = 1280;
  const aspect = source.videoWidth / source.videoHeight || 9 / 16;
  let width = maxW, height = Math.round(width / aspect);
  if (height > maxH) { height = maxH; width = Math.round(height * aspect); }
  width = Math.max(2, width - (width % 2)); height = Math.max(2, height - (height % 2));
  const canvas = document.createElement('canvas');
  canvas.width = width; canvas.height = height;
  const ctx = canvas.getContext('2d');
  const stream = canvas.captureStream(30);
  let audioContext, audioSource, audioDestination;
  try {
    audioContext = new (window.AudioContext || window.webkitAudioContext)();
    audioSource = audioContext.createMediaElementSource(source);
    audioDestination = audioContext.createMediaStreamDestination();
    audioSource.connect(audioDestination);
    audioSource.connect(audioContext.destination);
    audioDestination.stream.getAudioTracks().forEach(t => stream.addTrack(t));
  } catch (e) { console.warn('Audio capture unavailable; exporting video without audio.', e); }
  const mimeTypes = ['video/webm;codecs=vp9,opus', 'video/webm;codecs=vp8,opus', 'video/webm'];
  const mimeType = mimeTypes.find(t => MediaRecorder.isTypeSupported(t)) || '';
  const recorder = new MediaRecorder(stream, mimeType ? { mimeType } : undefined);
  const chunks = [];
  recorder.ondataavailable = e => { if (e.data && e.data.size) chunks.push(e.data); };
  const stopped = new Promise((resolve, reject) => { recorder.onstop = resolve; recorder.onerror = () => reject(new Error('Recorder error')); });
  const draw = () => {
    ctx.fillStyle = '#090912'; ctx.fillRect(0, 0, width, height);
    const scale = Math.max(width / source.videoWidth, height / source.videoHeight);
    const dw = source.videoWidth * scale, dh = source.videoHeight * scale;
    ctx.drawImage(source, (width - dw) / 2, (height - dh) / 2, dw, dh);
    if (clip.title) {
      const fontSize = Math.max(22, Math.round(width * 0.055));
      ctx.font = `800 ${fontSize}px Arial, sans-serif`;
      ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
      const lines = wrapText(ctx, clip.title.toUpperCase(), width * 0.82);
      const lineH = fontSize * 1.25;
      let y = clip.position === 'top' ? height * 0.16 : clip.position === 'center' ? height * 0.5 : height * 0.82;
      if (clip.position === 'center') y -= ((lines.length - 1) * lineH) / 2;
      if (clip.position === 'bottom') y -= ((lines.length - 1) * lineH) / 2;
      lines.forEach((line, i) => {
        const yy = y + i * lineH;
        ctx.lineWidth = Math.max(3, fontSize * 0.14); ctx.strokeStyle = 'rgba(0,0,0,.8)';
        ctx.strokeText(line, width / 2, yy);
        ctx.fillStyle = '#ffffff'; ctx.fillText(line, width / 2, yy);
      });
    }
  };
  function frameLoop() { if (!source.paused && !source.ended) { draw(); requestAnimationFrame(frameLoop); } }
  source.currentTime = clip.start;
  await new Promise(resolve => { source.onseeked = resolve; });
  if (audioContext?.state === 'suspended') await audioContext.resume();
  recorder.start(250);
  await source.play();
  draw(); frameLoop();
  await new Promise(resolve => {
    const check = () => {
      if (source.currentTime >= clip.end || source.ended) { source.pause(); resolve(); }
      else requestAnimationFrame(check);
    };
    check();
  });
  draw(); recorder.stop(); await stopped;
  source.pause(); stream.getTracks().forEach(t => t.stop());
  if (audioContext) await audioContext.close().catch(() => {});
  const blob = new Blob(chunks, { type: recorder.mimeType || 'video/webm' });
  if (!blob.size) throw new Error('Empty export');
  const fileName = `editnova-${Date.now()}.webm`;
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a'); a.href = url; a.download = fileName; a.click();
  setTimeout(() => URL.revokeObjectURL(url), 60000);
  showToast(`Export ready: ${fileName}. This prototype exports WebM.`);
}
function wrapText(ctx, text, maxWidth) {
  const words = text.split(/\s+/); const lines = []; let line = '';
  for (const word of words) {
    const test = line ? `${line} ${word}` : word;
    if (ctx.measureText(test).width > maxWidth && line) { lines.push(line); line = word; }
    else line = test;
  }
  if (line) lines.push(line);
  return lines;
}

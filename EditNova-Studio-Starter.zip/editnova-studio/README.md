# EditNova Studio (starter v0.1.0)

A mobile-first video editor prototype built with Vite and plain JavaScript. The same web project can be published as a website and wrapped as an Android app with Capacitor.

## Included in this starter
- Import multiple local video files
- Select and remove clips in a simple timeline
- Preview a selected clip
- Set trim start and end
- Add a title overlay and choose its position
- Export the selected segment to WebM using browser canvas recording (audio capture depends on browser/device support)
- Responsive UI for phone and desktop

## Important limitations
This is a starter prototype, not a complete CapCut replacement. Export uses browser `MediaRecorder`, so output is usually WebM, not MP4. Browser recording and audio capture support vary by device. The first version does not yet render a multi-clip sequence, music tracks, transitions, effects, captions, keyframes, or undo history. Test with short, non-sensitive clips first.

## Requirements
- Node.js 20 or newer (recommended)
- npm
- For Android APK: Android Studio, Android SDK, and a JDK supported by your installed Android Studio
- For phone-only testing: use an online development environment that supports Node/Vite, or develop on the laptop and open the LAN URL on your phone

## Run on laptop
1. Install Node.js LTS from https://nodejs.org/
2. Extract this ZIP.
3. Open a terminal in the `editnova-studio` folder.
4. Run:
   ```bash
   npm install
   npm run dev
   ```
5. Open the local URL Vite prints, usually `http://localhost:5173`.
6. On your phone on the same Wi-Fi, open `http://YOUR-LAPTOP-LAN-IP:5173`. If it doesn't connect, check your firewall and ensure both devices use the same network.

## Build the website
```bash
npm install
npm run build
```
The deployable site is created in `dist/`. Publish that folder using a static host such as GitHub Pages, Netlify, or Cloudflare Pages. For a first deployment, Netlify/Cloudflare Pages may be easier than GitHub Pages because the root path is straightforward.

## Create the Android project
1. Install Android Studio and open it once so it can install the Android SDK.
2. In the project terminal:
   ```bash
   npm install
   npx cap add android
   npm run android:sync
   npx cap open android
   ```
3. In Android Studio, wait for Gradle sync to finish.
4. Connect your own Android phone with USB debugging enabled, or use an emulator.
5. Press Run to install the debug build.
6. To create a debug APK, use **Build > Build Bundle(s) / APK(s) > Build APK(s)**. Android Studio shows the output path when finished.

If `npx cap add android` says the Android platform already exists, skip that command and continue with `npm run android:sync`.

## Deploy as a website
A typical static-host configuration:
- Build command: `npm run build`
- Publish/output directory: `dist`

## Monetization — later phase
Do not put ads in the editor canvas or interrupt exports. Add monetization only after the core editor is stable:
- Free: core trim, title, and basic export.
- Premium: extra title styles, presets, and project backups.
- Ads: optional rewarded ad for a bonus preset/export perk, where the ad network's policies and platform rules permit it.
- Use Google AdMob for a native Android app only after checking current requirements, consent/privacy requirements, and account eligibility. Do not add deceptive ads or fake export/progress buttons.
- Clearly disclose any analytics, ad tracking, or cloud upload. This starter processes imported videos locally in the browser and does not upload them.

## Suggested roadmap
1. Validate import, trim, title, and export across Android Chrome and desktop Chrome.
2. Add saved project metadata (do not store huge video files in localStorage).
3. Add multi-clip export using a proper media-processing engine.
4. Add soundtrack/music track, volume controls, and fades.
5. Add transitions, filters, text animation, and undo/redo.
6. For dependable MP4 and multi-track rendering, integrate a maintained media-processing solution or native Android media pipeline; check license, device compatibility, bundle size, and performance before choosing.
7. Add sign-in/cloud projects only if truly needed, with a clear privacy policy.

## Copyright and safety
Use original or properly licensed videos, fonts, images, and audio. Popular anime footage/music may be copyrighted; credit alone does not grant permission.
